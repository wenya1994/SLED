import cv2 as cv
import numpy as np
from utils import map_pixel_nodes, graph_fts, connect_n6_krandom, Weighting, generate_mask
from config import cashfile


def creating_graph(sobel_path):
    # ----------------------------------------构建图------------------------------------------------
    roi_p = np.load(cashfile + "roi_expectation.npy")  # 读取ROI区域的原始GT值, 已经转化为了概率值，未做阈值化

    roi_label = np.load(cashfile + "roi_prediction.npy")  # ROI区域的标签信息：0, 1, 2

    roi_unreliable = np.load(cashfile + "roi_unreliable.npy")  # ROI区域中的不可靠区域, 值域0~1, 1标识不可靠区域

    roi_image = np.load(cashfile + "roi_image.npy")  # ROI区域的图像

    graph_area_in_roi = np.load(cashfile + "graph_roi.npy")  # 值域0~1, 1标识ROI区域，为Graph的工作区域

    # 对ROI区域的图像进行标准化
    num_pixel = float(roi_image.shape[0] * roi_image.shape[1] * roi_image.shape[2])  # 计算像素个数
    mean_image = roi_image.sum() / num_pixel  # 计算像素均值
    sigma_image = np.sum((roi_image - mean_image) ** 2) / num_pixel
    color_features = (roi_image - mean_image) / sigma_image

    # 标准化sobel特征
    sobel_features = cv.imread(sobel_path, 0)
    roi_limits = np.load(cashfile + "limits.npy")
    sobel_features = sobel_features[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]]
    num_point = float(sobel_features.shape[0] * sobel_features.shape[1])
    mean_so = sobel_features.astype(np.float32).sum() / num_point
    fangcha_so = np.sum((sobel_features.astype(np.float32) - mean_so) ** 2) / num_pixel
    sobel_fts = np.array(sobel_features, dtype=np.float32)
    sobel_fts = (sobel_fts - mean_so) / fangcha_so

    # 叠加ROI区域的图像的颜色特征和注释概率特征 3+1->4通道
    new_p = np.expand_dims(roi_p, axis=0)  # 在第一个维度上增加一个维度,方便叠加
    sobel_fts = np.expand_dims(sobel_fts, axis=0)
    features = np.concatenate((color_features, new_p, sobel_fts), axis=0)

    # 生成一个字典, 一个二维数组
    pixel_node, node_pixel = map_pixel_nodes(roi_image.shape, graph_area_in_roi.astype(np.bool))

    # 将特征转化为图representation
    ft_graph = graph_fts(features, node_pixel)

    args = {
        "image": color_features,  # 标准化后的图像
        "sobel": (sobel_features - mean_so) / fangcha_so,
        "label": roi_label,  # ROI区域的label：0，1，2
        "probability": roi_p,  # ROI区域的原始GT概率
        "uncertainty": roi_unreliable,  # 标识ROI区域中的不可靠区域
        "features": features  # 特征
    }

    graph, weights, lb, N = connect_n6_krandom(ref=roi_label, pixel_node=pixel_node,
                                               node_pixel=node_pixel, working_nodes=graph_area_in_roi,
                                               k_random=16, weighting=Weighting(),
                                               args=args)
    uncertain_mask = generate_mask(roi_unreliable, node_pixel)

    np.save(cashfile + "graph.npy", graph)  # 哪两个ID的节点之间有边 (266894, 2)
    np.save(cashfile + "graph_weights.npy", weights)  # 每条边上的权重：0.5 * w1 + w2 + w3  (266894,)
    np.save(cashfile + "graph_node_features.npy", ft_graph)  # [13373, 5]  所有节点构成的特征矩阵
    np.save(cashfile + "graph_ground_truth.npy", lb)  # CNN prediction without drop时提供的label信息    (13373,)
    np.save(cashfile + "unc_mask.npy", uncertain_mask)  # 不确定性的点，不参与训练的部分。以可靠像素样本为中心的构建的Graph才参与训练

    # print("------------构建图的结果-----------")
    # print("图的形状: {}".format(graph.shape))
    # print("权重的形状: {}".format(weights.shape))
    # print("图特征的形状: {}".format(ft_graph.shape))  # RGB3通道,期望值的1通道,熵值的1通道
    # print("训练样本的标签形状: {}".format(lb.shape))
    # print("不确定性像素mask的形状: {}".format(uncertain_mask.shape))
    # print("参与计算的node数量: {}".format(np.sum(graph_area_in_roi)))
    # print("不可靠node的数量: {}".format(int(np.sum(uncertain_mask))))
    # print("可靠的node的数量: {}".format(int(N - np.sum(uncertain_mask))))
    # print("可靠的阴影node数量: {}".format(np.sum(lb[np.where(uncertain_mask == 0)[0]] >= 1)))
    # print("可靠的非阴影node数量: {}".format(np.sum(lb[np.where(uncertain_mask == 0)[0]] == 0)))
