import glob
import os
import os.path as osp

training_on_Linux = False

# -------------无需更改-----------------
cashfile = "./file/"
if not osp.isdir(cashfile):
    os.makedirs(cashfile)
shadow_dir = sorted(glob.glob("./data/image/*.jpg"))
if training_on_Linux:
    sp = "/"
else:
    sp = "\\"
