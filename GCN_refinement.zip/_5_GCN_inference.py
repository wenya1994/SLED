import os
import cv2 as cv
import os.path as osp
import numpy as np
from config import shadow_dir, cashfile, sp
from utils import reconstruct_from_n4, map_pixel_nodes


def GCN_inference(model, adj, features, i, gcn_th=0.3):
    img = np.load("./file/image.npy")
    roi_limits = np.load(cashfile + "limits.npy")  # roi的边界:矩形
    segmentation = np.load(cashfile + "roi_prediction.npy")  # roi区域的标准预测值

    roi_shadow = np.load(cashfile + "roi_image.npy")  # ROI区域的阴影图像  矩形

    valid_nodes = np.load(cashfile + "graph_roi.npy")  # ROI中通过膨胀操作得到的区域，包含所有的图节点（图工作区域）
    model.eval()
    output = model(features, adj)

    pixel_node, node_pixel = map_pixel_nodes(roi_shadow.shape, valid_nodes.astype(np.bool))
    graph_predictions = (output > gcn_th).cpu().numpy().astype(np.float32)
    graph_predictions = reconstruct_from_n4(graph_predictions, node_pixel,
                                            roi_shadow.shape)  # recovering the volume shape

    refined = graph_predictions

    # 恢复原图大小，方便测试
    segmentation_expanded = np.zeros(img.shape[1:], dtype=np.float)
    segmentation_expanded[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]] = segmentation

    refined_expanded = np.zeros(img.shape[1:], dtype=np.float)
    refined_expanded[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]] = refined

    image_path = shadow_dir[i]
    file_name = image_path.split(sp)[-1].split(".")[0]

    # 可视化
    save = "./data/result/"
    if not osp.isdir(save):
        os.makedirs(save)
    refined_expanded = (refined_expanded * 255).astype(np.uint8)
    cv.imwrite(save + file_name + ".jpg", refined_expanded)
