import torch
import numpy as np
import scipy.sparse as sp
import torch.nn.functional as F
from torchvision import transforms

# 创建transform
transform = transforms.Compose([
    transforms.ToTensor()
])


def map_pixel_nodes(shape, include_nodes):
    channel, height, width = shape  # 3*383*543
    N = np.sum(include_nodes.astype(np.int))  # ROI区域覆盖的所有像素个数 29882
    pixel_node = {}
    node_pixel = np.zeros(shape=(N, 2), dtype=np.int)
    node_index = 0
    for h in range(height):
        for w in range(width):
            if not include_nodes[h, w]:  # 如果该像素为ROI区域的话
                continue
            node_pixel[node_index] = [h, w]  # 把ROI区域的像素，依次从1开始排序，然后把其坐标存到node_pixel中去
            pixel_node[h, w] = node_index
            node_index += 1
    return pixel_node, node_pixel  # node_pixel 中存储的是ROI中像素的坐标  pixel_node = {} 字典存储的是 坐标：节点计数


def graph_fts(fts, node_pixel):
    N = node_pixel.shape[0]  # 节点个数 13373
    K = fts.shape[0]  # 每个节点的特征个数
    ft_mat = np.zeros(shape=(N, K), dtype=np.float32)  # 节点特征矩阵 13373行 5维
    for node_idx in range(N):
        h, w = node_pixel[node_idx]
        ft_mat[node_idx, :] = fts[:, h, w]
    return ft_mat


def supervised_loss(prediction, label):
    mask = label.clone()
    num_positive = torch.sum((mask == 1).float()).float()
    num_negative = torch.sum((mask == 0).float()).float()

    mask[mask == 1] = num_negative / (num_positive + num_negative)
    mask[mask == 0] = num_positive / (num_positive + num_negative)
    cost = F.binary_cross_entropy(prediction, label, weight=mask)
    return cost  # torch.cuda.FloatTensor


def normalize(mx):
    """行归一化"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def normalize_adj(adj):
    """行归一化"""
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def accuracy(output, labels):
    preds = (output > 0.5).type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def reconstruct_from_n4(ft_mat, map_vector, shape, dtype=np.uint8):
    _, ys, xs = shape
    N = map_vector.shape[0]
    rec_vol = np.zeros(shape=(ys, xs), dtype=dtype)
    for i in range(N):
        y, x = map_vector[i]
        rec_vol[y, x] = dtype(ft_mat[i])
    return rec_vol


def connect_n6_krandom(ref, pixel_node, node_pixel, working_nodes, k_random, weighting, args):
    edges = []  # 二维矩阵，表示ID*和ID*的节点之间连接在一起
    labels = []  # CNN prediction‘s label
    num_nodes = node_pixel.shape[0]  # 图节点个数
    tabu_list = {}  # A list to avoid duplicated elements in the adjacency matrix. 邻接矩阵
    nodes_complete = {}  # A list counting how many neighbors a node already has.  度矩阵
    valid_nodes = np.array(np.where(working_nodes > 0))  # 返回所有图节点的坐标
    valid_nodes = np.transpose(valid_nodes)  # valid_nodes 等价于 node_pixel

    for node_idx in range(num_nodes):
        y, x = node_pixel[node_idx]  # getting the position for current node
        labels.append(ref[y, x])  # CNN prediction提供的label信息
        #  基础的4领域连接
        for axis in range(2):
            axisy = int(axis == 0)
            axisx = int(axis == 1)
            for ne in [-1, 1]:
                neighbor = y + axisy * ne, x + axisx * ne
                if neighbor not in pixel_node:  # 如果四领域中的点不在ROI区域中,放弃该节点
                    continue
                ne_idx = pixel_node[neighbor]  # 否则拿出节点的ID
                if (node_idx, ne_idx) not in tabu_list and (ne_idx, node_idx) not in tabu_list:  # 判断某两个节点的边是否存在
                    tabu_list[(node_idx, ne_idx)] = 1  # adding the edge to the tabu list
                    # 给新增节点到中心节点的边上增加权重
                    weighting.weights_for((y, x), neighbor, args)  # 计算权重并保存到权重矩阵中
                    weighting.weights_for(neighbor, (y, x), args)  # 保存其对称位置的权重
                    edges.append([node_idx, ne_idx])  #
                    edges.append([ne_idx, node_idx])

        #  K个随机节点
        for j in range(k_random):
            valid_neigh = False
            if node_idx not in nodes_complete:
                nodes_complete[node_idx] = 0
            elif nodes_complete[node_idx] == k_random:
                break

            while not valid_neigh:
                lu_idx = np.random.randint(low=0, high=num_nodes)  # we look for a random node.
                yl, xl = valid_nodes[lu_idx]  # getting the euclidean coordinates for the voxel.
                lu_idx = pixel_node[yl, xl]  # getting the node index.
                if lu_idx not in nodes_complete:
                    nodes_complete[lu_idx] = 0
                    valid_neigh = True
                elif nodes_complete[lu_idx] < k_random:
                    valid_neigh = True

            if not (node_idx, lu_idx) in tabu_list and not (lu_idx, node_idx) in tabu_list \
                    and node_idx != lu_idx:  # checking if the edge was already generated
                weighting.weights_for((y, x), (yl, xl), args)  # computing the weight for the current pair.
                weighting.weights_for((yl, xl), (y, x), args)
                tabu_list[(node_idx, lu_idx)] = 1
                edges.append([node_idx, lu_idx])
                #  Adding the weight in the opposite direction
                edges.append([lu_idx, node_idx])
                #  Increasing the amount of neighbors connected to each node
                nodes_complete[node_idx] += 1
                nodes_complete[lu_idx] += 1
    edges = np.asarray(edges, dtype=int)  # [[0,40], [40,0]...........]    0-th到40-th节点上有边  40-th到0-th节点上有边
    pp_args = {
        "edges": edges,  # 所有的边   [266896, 2]
        "num_nodes": num_nodes  # 节点的个数  13373 * (4+16)
    }
    # print(weighting.weights1)   # 所有边上的期望相似性   例如0-th到40-th节点边上的权重
    weighting.post_process(pp_args)  # Applying weight post-processing, e.g. normalization
    weights = weighting.get_weights()  # weight1, weight2, weight3     # (13373, 13373)
    edges, weights, _ = sparse_to_tuple(weights)  # edges: (266896, 2)  weights: (266896,)
    return edges, weights, np.asarray(labels, dtype=np.float32), num_nodes


def sparse_to_tuple(sparse_mx):
    """Convert sparse matrix to tuple representation."""

    def to_tuple(mx):
        if not sp.isspmatrix_coo(mx):
            mx = mx.tocoo()
        coords = np.vstack((mx.row, mx.col)).transpose()
        values = mx.data
        shape = mx.shape
        return coords, values, shape

    if isinstance(sparse_mx, list):
        for i in range(len(sparse_mx)):
            sparse_mx[i] = to_tuple(sparse_mx[i])
    else:
        sparse_mx = to_tuple(sparse_mx)

    return sparse_mx


def generate_mask(unc_image, node_pixel, th=0):
    num_nodes = node_pixel.shape[0]
    mask = np.zeros(shape=(num_nodes, 1), dtype=np.float32)
    for node_idx in range(num_nodes):
        y, x = node_pixel[node_idx]
        mask[node_idx] = float(unc_image[y, x] > th)
    return mask


class Weighting():
    def __init__(self):
        super(Weighting, self).__init__()
        self.description = "概率值特征 + 颜色特征 + 空间位置特征 + 边缘特征"
        self.weights1 = []
        self.weights2 = []
        self.weights3 = []
        self.weights4 = []

    def weights_for(self, idx1, idx2, args):
        prob1 = args["probability"][idx1]  # 节点1的预测期望值
        prob2 = args["probability"][idx2]  # 节点2的预测期望值

        int1 = args["image"][:, idx1[0], idx1[1]]  # 节点1的三通道像素值
        int2 = args["image"][:, idx2[0], idx2[1]]  # 节点2的三通道像素值

        so1 = args["sobel"][idx1[0], idx1[1]]  # 节点1的sobel值
        so2 = args["sobel"][idx2[0], idx2[1]]  # 节点2的sobel值

        _, ny, nx = args["image"].shape  # limit区域的高和宽
        dim_array = np.array([ny, nx], dtype=np.float32)  # 新建一个与limit长宽一致的array
        pos1 = np.array(idx1, dtype=np.float32) / dim_array  # 归一化节点1的position
        pos2 = np.array(idx2, dtype=np.float32) / dim_array  # 归一化节点2的position

        #   计算两个节点之间的相似性：节点的期望预测值，RGB三通道的值，节点的空间位置
        # 因为数据提前做了标准化处理，所以以下算出来的结果均直接为相似性，不需要再除以方差，然后计算以e为底的对数值
        int_diff = int1 - int2  # 颜色差异
        pos_diff = pos1 - pos2  # 空间位置差异
        so_diff = so1 - so2  # sobel差异

        intensity = np.sum(int_diff * int_diff)  # 颜色的L2 distance
        space = np.sum(pos_diff * pos_diff)  # 空间位置的L2 distance
        sobel = np.sum(so_diff * so_diff)
        p = prob1 - prob2
        delta = 1.0e-15
        lambd = p * (np.log2(prob1 / (prob2 + delta) + delta) - np.log2((1 - prob1) / ((1 - prob2) + delta) + delta))

        self.weights1.append(lambd)  # 保存该节点的期望相似性
        self.weights2.append(intensity)  # 保存该节点的颜色相似性
        self.weights3.append(space)  # 保存该节点的空间位置相似性
        self.weights4.append(sobel)

    def post_process(self, args=None):
        self.weights1 = np.asarray(self.weights1, dtype=np.float32)  # 266896
        self.weights2 = np.asarray(self.weights2, dtype=np.float32)  # 266896
        self.weights3 = np.asarray(self.weights3, dtype=np.float32)  # 266896
        self.weights4 = np.asarray(self.weights4, dtype=np.float32)  # 266896

        num_nodes = args["num_nodes"]  # ROI区域节点个数  13373
        ne = float(self.weights1.shape[0])  # number of edges 边的数量

        muw2 = self.weights2.sum() / ne  # weight2的平均值
        muw3 = self.weights3.sum() / ne  # weight3的平均值
        muw4 = self.weights4.sum() / ne

        sig2 = 2 * np.sum((self.weights2 - muw2) ** 2) / ne  # 权重2的方差
        sig3 = 2 * np.sum((self.weights3 - muw3) ** 2) / ne  # 权重3的方差
        sig4 = 2 * np.sum((self.weights4 - muw4) ** 2) / ne

        self.weights2 = np.exp(-self.weights2 / sig2)
        self.weights3 = np.exp(-self.weights3 / sig3)
        self.weights4 = np.exp(-self.weights4 / sig4)

        w1 = sp.coo_matrix((self.weights1, (args["edges"][:, 0], args["edges"][:, 1])), shape=(num_nodes, num_nodes))
        w2 = sp.coo_matrix((self.weights2, (args["edges"][:, 0], args["edges"][:, 1])), shape=(num_nodes, num_nodes))
        w3 = sp.coo_matrix((self.weights3, (args["edges"][:, 0], args["edges"][:, 1])), shape=(num_nodes, num_nodes))
        w4 = sp.coo_matrix((self.weights4, (args["edges"][:, 0], args["edges"][:, 1])), shape=(num_nodes, num_nodes))

        self.weights = 0.2 * w1 + 2 * w4  # 经过消融分析，发现颜色和空间位置的权重对于标签传播没有任何帮助

    def get_weights(self):
        return self.weights


def bounding_cube(vol):
    a = np.where(vol != 0)
    box = np.min(a[0]), np.max(a[0]), np.min(a[1]), np.max(a[1])
    return box
