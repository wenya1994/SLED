import glob
import time

from _1_preprocess import data_prepocess
from _2_roi import roi
from _3_creating_graph import creating_graph
from _4_GCN_training import GCN_training
from _5_GCN_inference import GCN_inference

if __name__ == '__main__':
    image_paths = sorted(glob.glob("./data/image/*.jpg"))
    expectation_paths = sorted(glob.glob("./data/expectation/*.png"))  # 期望
    # 数据预处理，提取可靠边缘点，提取sobel特征保存到data文件夹下,仅执行一次
    data_prepocess(expectation_paths, image_paths)
    sobel_path = sorted(glob.glob("./data/sobel_feature/*.jpg"))
    # 循环所有的图像，每个图像对应一个GCN模型，每个图像中形成的graphs为该模型的训练样本
    # print(len(image_paths))
    for i in range(len(image_paths) - 2):
        print("----------%3s/%s image processing----------" % (i + 1, len(image_paths)))
        start_time = time.time()  # 记录开始处理图片的时间
        image_path = image_paths[i]
        expectation_path = expectation_paths[i]
        # 寻找一个最小的ROI区域，能够包含所有的可靠样本，降低图的数据量
        roi(image_path, expectation_path)
        # 以每个可靠样本（包含可靠的边缘像素和可靠的非边缘像素）为中心构建4领域和16随机节点的graph，提取图的特征，计算节点到节点间的权重
        creating_graph(sobel_path[i])
        # 为单张图像建模，训练的时候，只训练可靠graph
        model, adj, features, idx_test = GCN_training(epochs=350, dropout=0.4)
        # 测试时，预测所有graph作为最终的结果
        GCN_inference(model, adj, features, i)
        end_time = time.time()  # 记录完成处理图片的时间
        processing_time = end_time - start_time  # 计算处理一张图片的时间
        print("Processing time for image %s: %.2f seconds" % (i + 1, processing_time))
