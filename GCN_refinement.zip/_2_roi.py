import cv2 as cv
import numpy as np
from PIL import Image
from config import cashfile
from utils import bounding_cube, transform


def roi(image_path, expectation_path):
    image = transform(Image.open(image_path)).numpy()
    expectation = cv.imread(expectation_path, 0)
    unreliable_sample = np.zeros(expectation.shape, dtype=np.uint8)
    height, width = expectation.shape[0:]
    count_us = 0
    for h in range(height):
        for w in range(width):
            if expectation[h, w] > 10 and expectation[h, w] <= 127:
                unreliable_sample[h, w] = 255
                count_us += 1
            else:
                unreliable_sample[h, w] = 0
    # 归一化原始gt
    np.save(cashfile + "image.npy", image)
    np.save(cashfile + "expectation.npy", expectation.astype(np.float32) / float(255))

    # cv.imshow("unreliable_sample", unreliable_sample)
    # cv.waitKey(0)
    # cv.destroyAllWindows()

    roi_limits = bounding_cube(unreliable_sample)  # 找到unreliable_sample，构建最小外接矩形包围所有像素， roi_limits 为四个坐标
    np.save(cashfile + "limits.npy", np.asanyarray(roi_limits))

    image_roi = image[:, roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]]  # 归一化
    expectation_roi = expectation[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]]  # 归一化
    np.save(cashfile + "roi_image.npy", image_roi)
    np.save(cashfile + "roi_expectation.npy", expectation_roi.astype(np.float32) / float(255))

    unreliable_roi = unreliable_sample[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]]
    np.save(cashfile + "roi_unreliable.npy", unreliable_roi.astype(np.float32) / float(255))  # ROI区域高不确定性的像素点

    # 对不可靠区域进行膨胀操作
    kernel = np.ones((3, 3), np.uint8)
    dilated = cv.dilate(unreliable_roi, kernel)
    np.save(cashfile + "graph_roi.npy", dilated.astype(np.float32) / float(255))

    # cv.imshow("dilated", dilated)
    # cv.waitKey(0)
    # cv.destroyAllWindows()

    # 合成标准的label信息，将可靠的边界像素点标签设置为1，可靠的非边界像素点设置为0，不确定的区域设置为0.5
    label = np.zeros((height, width), dtype=np.uint8)
    for h in range(height):
        for w in range(width):
            if expectation[h, w] > 127:
                label[h, w] = 1  # 可靠的边界像素
            elif expectation[h, w] == 0:
                label[h, w] = 0  # 可靠的非边界像素
            else:
                label[h, w] = 2  # 不可靠像素
    roi_label = label[roi_limits[0]:roi_limits[1], roi_limits[2]:roi_limits[3]]
    np.save(cashfile + "roi_prediction.npy", roi_label.astype(np.float32))  # 非归一化的值，作为label

    cv.imshow("roi_label", roi_label)
    cv.waitKey(0)
    cv.destroyAllWindows()