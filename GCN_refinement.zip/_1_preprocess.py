import os
import cv2 as cv
import os.path as osp
from config import sp


# 提取existing deep learning-based 方法认为可靠的像素点
def reliable_sample_computing(read, save):
    if not osp.isdir(save):
        os.makedirs(save)
    image_paths = read
    for image_path in image_paths:
        image_name = image_path.split(sp)[-1].split(".")[0]
        save_dir = save + image_name + ".jpg"

        image = cv.imread(image_path, 0)
        hight, width = image.shape[0:]
        for h in range(hight):
            for w in range(width):
                if image[h, w] >= 127.5:
                    image[h, w] = 255
                else:
                    image[h, w] = 0
        cv.imwrite(save_dir, image)


# 提取sobel特征，作为后续图节点的特征之一
def sobel_features_computing(read, save):
    if not osp.isdir(save):
        os.makedirs(save)
    image_paths = read
    for image_path in image_paths:
        image_name = image_path.split(sp)[-1].split(".")[0]
        save_dir = save + image_name + ".jpg"
        src = cv.imread(image_path, 0)
        sobelx = cv.Sobel(src, cv.CV_64F, 1, 0)
        sobely = cv.Sobel(src, cv.CV_64F, 0, 1)
        sobelx = cv.convertScaleAbs(sobelx)
        sobely = cv.convertScaleAbs(sobely)
        sobelxy = cv.add(sobelx, sobely)
        cv.imwrite(save_dir, sobelxy)


def data_prepocess(x, y):
    reliable_save_dir = "./data/reliable_sample/"
    sobel_dir = "./data/sobel_feature/"
    reliable_sample_computing(x, reliable_save_dir)
    sobel_features_computing(y, sobel_dir)
